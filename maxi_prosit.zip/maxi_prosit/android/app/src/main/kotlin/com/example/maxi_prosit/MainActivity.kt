package com.example.maxi_prosit

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
